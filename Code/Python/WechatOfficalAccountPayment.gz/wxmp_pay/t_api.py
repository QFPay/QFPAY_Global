# https://overseaopenapitest.qfpay.com/mppaytest/xxx.html?code=01102AWe0K0Buz1tGPXe0ChrWe002AWY&state=
import json

import requests
import urllib
import flask
import t_qiantai
from flask import request, jsonify


app = flask.Flask(__name__)

appid = 'wxdc3dcdb71eabcc4a'
appsecret = '621191249902d5358183f9ccc6844a7f'


@app.route('/mppaytest/api/get_code', methods=['GET'])
def get_code():
    d = dict(
        appid=appid,
        redirect_uri='https://overseaopenapitest.qfpay.com/mppaytest/xxx.html',
        scope='snsapi_base',
        response_type='code',
        state='',
    )
    redirect_url = 'https://open.weixin.qq.com/connect/oauth2/authorize?' + urllib.urlencode(d) + '#wechat_redirect'
    print redirect_url

    return flask.redirect(redirect_url)


@app.route('/mppaytest/api/get_openid', methods=['GET'])
def get_openid():
    print request.user_agent
    if 'Mobile' in str(request.user_agent):
        pass
        # return ''

    access_url = 'https://api.weixin.qq.com/sns/oauth2/access_token'
    print 'request.args', request.args

    code = request.args.get('code')
    if not code:
        return 'code NOT found'

    params = {
        'appid': appid,
        'secret': appsecret,
        'code': code,
        'grant_type': 'authorization_code'

    }
    resp = requests.get(
        access_url + '?' + urllib.urlencode(params)
    )
    resp_dict = json.loads(resp.content)
    print 'resp_dict', resp_dict
    return jsonify(
        openid=resp_dict['openid'],
    )


@app.route('/mppaytest/api/get_pay_params', methods=['GET'])
def pay():
    openid = request.args.get('openid')
    if not openid:
        return 'openid NOT found'
    precreate_req_dict = t_qiantai.req
    precreate_req_dict['sub_openid'] = openid

    precreate_resp_dict = t_qiantai.do_req(precreate_req_dict)


    ret = flask.Response(
        status='200'
    )
    ret.set_data(json.dumps(precreate_resp_dict['pay_params']))
    ret.headers['Content-Type'] ='application/json'

    return ret



def main():
    app.run(
        debug=True,
        host='0.0.0.0',
        port=5000,
    )

if __name__ == '__main__':
    main()