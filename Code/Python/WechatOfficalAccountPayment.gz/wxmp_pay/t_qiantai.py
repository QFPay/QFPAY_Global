# coding=utf-8
import hashlib
import json
import time

import datetime

import requests

mchid = 'eqqmYMn0Zj6pncw5ZDxjgMqbzV'
appcode = '123456'
appkey = '123456'
pay_type = '800207'
out_trade_no = str(int(time.time()))
txdtm = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
txamt = 10
product_name = '钱方微信公众号支付测试'
udid = 'qfpay'
sub_openid = 'o49L5wWb9fvw9PQh4pU7WNoEzPzY'
lnglat = '0.0 0.0'


req  = {
    'mchid': mchid,
    'appcode': appcode,
    'pay_type': pay_type,
    'out_trade_no': out_trade_no,
    'txdtm': txdtm,
    'txamt': txamt,
    'product_name': product_name,
    'udid': udid,
    'sub_openid': sub_openid,
    'lnglat': lnglat,
}

def smart_utf8(s):
    if isinstance(s, unicode):
        return s.encode('utf8')
    else:
        return str(s)

def do_req(req_dict):
    param_list = [
        '%s=%s' % (smart_utf8(key), smart_utf8(req[key]))
        for key in sorted(req.keys())
    ]
    print param_list
    req_str = '&'.join(param_list) + appkey
    print req_str

    md5 = hashlib.md5()
    md5.update(req_str)
    sign_str = md5.hexdigest().upper()

    resp = requests.post(
        url='https://osqt.qfpay.com' + '/trade/v1/payment',
        data=req,
        headers={
            'X-QF-APPCODE': appcode,
            'X-QF-SIGN': sign_str,
        }
    )
    # print '####, resp_str: ', resp.content
    resp_dict = json.loads(resp.content)
    print '####, pay_params: ', json.dumps(resp_dict['pay_params'])

    return resp_dict


def main():
    return do_req(req)

if __name__ == '__main__':
    main()
